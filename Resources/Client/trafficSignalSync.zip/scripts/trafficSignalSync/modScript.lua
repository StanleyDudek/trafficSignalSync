load('trafficSignalSync')
setExtensionUnloadMode('trafficSignalSync', 'manual')
